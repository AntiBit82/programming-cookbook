import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: true,
  template: `
    <h2>Welcome to the Angular Routing Example</h2>
    <p>This application demonstrates how to use Angular Router with parameters.</p>
    <p>Navigate to the Products page to see the example in action.</p>
  `
})
export class HomeComponent {}
