import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [RouterLink, CommonModule],
  template: `
    <h2>Products</h2>
    <ul>
      @for (product of products; track product.id) {
        <li>
          <a [routerLink]="['/products', product.id]">
            {{ product.name }}
          </a>
        </li>
      }
    </ul>
  `
})
export class ProductListComponent {
  products = [
    { id: 1, name: 'Laptop' },
    { id: 2, name: 'Phone' },
    { id: 3, name: 'Tablet' }
  ];
}
