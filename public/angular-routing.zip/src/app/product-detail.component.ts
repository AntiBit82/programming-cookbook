import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [CommonModule],
  template: `
    <h2>Product Details</h2>
    <p>Product ID: {{ productId }}</p>
    @if (product) {
      <div>
        <h3>{{ product.name }}</h3>
        <p>Price: {{ product.price }}</p>
      </div>
    }
  `
})
export class ProductDetailComponent implements OnInit {
  productId: string = '';
  product: any = null;
  
  // Mock product data
  products = [
    { id: '1', name: 'Laptop', price: '$999' },
    { id: '2', name: 'Phone', price: '$699' },
    { id: '3', name: 'Tablet', price: '$499' }
  ];
  
  constructor(private route: ActivatedRoute) {}
  
  ngOnInit() {
    // Get the parameter from the route
    this.productId = this.route.snapshot.paramMap.get('id') || '';
    
    // Find the product by ID
    this.product = this.products.find(p => p.id === this.productId);
  }
}
