import { Component } from '@angular/core';
import { SkillsFormComponent } from './skills-form.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [SkillsFormComponent],
  template: `
    <div class="container">
      <h1>Angular FormArray Example</h1>
      <p>This example demonstrates how to use FormArray for dynamic form fields with data binding.</p>
      <app-skills-form></app-skills-form>
    </div>
  `,
  styles: [`
    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 2rem;
    }
    
    h1 {
      text-align: center;
      color: #333;
      margin-bottom: 1rem;
    }
    
    p {
      text-align: center;
      color: #666;
      margin-bottom: 2rem;
    }
  `]
})
export class AppComponent {}
