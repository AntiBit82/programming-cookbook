import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormArray, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

interface User {
  name: string;
  skills: string[];
}

@Component({
  selector: 'app-skills-form',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './skills-form.component.html',
  styleUrls: ['./skills-form.component.css']
})
export class SkillsFormComponent implements OnInit {
  // Initial data object
  user: User = {
    name: 'John',
    skills: ['TypeScript', 'Angular', 'RxJS']
  };
  
  profileForm = new FormGroup({
    name: new FormControl(''),
    skills: new FormArray<FormControl>([])
  });
  
  ngOnInit() {
    // Load data into form
    this.loadUserData();
    
    // Subscribe to form changes to update the user object
    this.profileForm.valueChanges.subscribe(value => {
      this.user = value as User;
    });
  }
  
  // Load user data into the form
  loadUserData() {
    this.profileForm.patchValue({ name: this.user.name });
    
    // Add skills from data
    this.user.skills.forEach(skill => {
      this.skills.push(new FormControl(skill));
    });
  }
  
  get skills() {
    return this.profileForm.get('skills') as FormArray;
  }
  
  addSkill() {
    this.skills.push(new FormControl(''));
  }
  
  removeSkill(index: number) {
    this.skills.removeAt(index);
  }
  
  onSubmit() {
    console.log('User object:', this.user);
  }
}
